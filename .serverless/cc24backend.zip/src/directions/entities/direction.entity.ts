export class Direction {}
