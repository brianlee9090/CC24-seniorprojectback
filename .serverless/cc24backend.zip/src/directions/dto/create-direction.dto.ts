export class CreateDirectionDto {}
