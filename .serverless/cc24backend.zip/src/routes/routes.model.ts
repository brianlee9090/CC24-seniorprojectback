import * as mongoose from "mongoose";

export const RouteSchema = new mongoose.Schema({
    stops: [{
        placeId: String,
        coord: [Number]
    }]
});

export interface StopInterface {
    placeId: string;
    coord: number[];
}