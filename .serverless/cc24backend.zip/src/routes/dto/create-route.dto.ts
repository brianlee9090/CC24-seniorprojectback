export class CreateRouteDto {}
