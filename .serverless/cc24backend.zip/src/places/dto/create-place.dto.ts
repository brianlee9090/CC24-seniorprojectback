export class CreatePlaceDto {}
